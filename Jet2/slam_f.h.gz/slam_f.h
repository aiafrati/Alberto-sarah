      integer*4 ift,iford,nfil
      real*8    c(1:7,0:7),d(1:7)
      common/filtro/c,d,ift,iford,nfil
